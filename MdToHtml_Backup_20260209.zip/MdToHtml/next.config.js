/** @type {import('next').NextConfig} */
const isProd = process.env.NODE_ENV === 'production';

const nextConfig = {
  // output: 'export', // Commented out to enable API routes for Data Loop feature in Dev mode
  // To build static site, use a specific build script that handles API exclusion
  trailingSlash: true, // Generate folder/index.html instead of file.html
  // assetPrefix removed: handled by post-build script for correct relative paths
  images: {
    unoptimized: true, // Required for static export
  },
}

module.exports = nextConfig
