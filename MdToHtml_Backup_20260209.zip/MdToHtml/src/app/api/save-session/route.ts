import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function POST(request: NextRequest) {
  console.log('API /api/save-session hit');
  try {
    const body = await request.json();
    console.log('Body received');
    const { slug, input, output, operations } = body;

    if (!slug || !input || !output) {
      console.error('Missing fields');
      return NextResponse.json(
        { error: 'Missing required fields: slug, input, output' },
        { status: 400 }
      );
    }

    // Ensure data directory exists
    const dataRoot = path.join(process.cwd(), '../data');
    console.log('Data root:', dataRoot);
    
    if (!fs.existsSync(dataRoot)) {
      console.log('Creating data root...');
      fs.mkdirSync(dataRoot, { recursive: true });
    }

    // Create session directory: data/{slug}_{timestamp}
    const safeSlug = slug.replace(/[\\/:*?"<>|]/g, '_');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const sessionDirName = `${safeSlug}_${timestamp}`;
    const sessionDir = path.join(dataRoot, sessionDirName);
    console.log('Session dir:', sessionDir);

    if (!fs.existsSync(sessionDir)) {
      fs.mkdirSync(sessionDir, { recursive: true });
    }

    // Write files
    fs.writeFileSync(path.join(sessionDir, 'input.md'), input, 'utf8');
    fs.writeFileSync(path.join(sessionDir, 'output.md'), output, 'utf8');
    
    const operationsData = JSON.stringify(operations || [], null, 2);
    fs.writeFileSync(path.join(sessionDir, 'operations.json'), operationsData, 'utf8');
    
    console.log('Files written successfully');

    return NextResponse.json({ success: true, path: sessionDirName });
  } catch (error) {
    console.error('Error saving session:', error);
    return NextResponse.json(
      { error: 'Failed to save session' },
      { status: 500 }
    );
  }
}
