import React from 'react';
import Link from 'next/link';
import { getAllPosts } from '@/lib/posts';
import { FileText, ChevronRight, Layout, PenTool } from 'lucide-react';
import { ThemeSwitcher } from '@/components/ThemeSwitcher';

export default function Home() {
  const posts = getAllPosts();

  return (
    <div className="flex h-screen bg-bg-page overflow-hidden transition-colors duration-300">
      {/* Left Sidebar */}
      <div className="w-64 bg-bg-card border-r border-border-soft flex flex-col shrink-0 transition-colors duration-300">
        <div className="h-14 flex items-center px-4 border-b border-border-soft">
           <div className="flex items-center gap-2 font-bold text-text-primary">
              <Layout className="w-5 h-5 text-primary" />
              <span>文档列表</span>
           </div>
        </div>
        <div className="flex-1 overflow-y-auto p-2 space-y-1">
           {posts.map((post) => (
             <Link 
               key={post.slug} 
               href={`/${post.slug}`}
               className="block px-3 py-2 rounded-md hover:bg-bg-page text-sm text-text-primary/80 hover:text-text-primary transition-colors flex items-center gap-2 group"
             >
               <FileText className="w-4 h-4 text-text-secondary group-hover:text-primary transition-colors" />
               <span className="truncate flex-1">{post.slug}</span>
               <ChevronRight className="w-3 h-3 text-text-secondary/50 opacity-0 group-hover:opacity-100 transition-opacity" />
             </Link>
           ))}
        </div>
        <div className="p-4 border-t border-border-soft">
           <Link 
             href="/editor"
             className="flex items-center justify-center w-full px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors text-sm font-medium gap-2"
           >
             <PenTool className="w-4 h-4" />
             进入编辑器
           </Link>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-5xl mx-auto">
          <header className="mb-8 flex justify-between items-start">
             <div>
               <h1 className="text-3xl font-bold text-text-primary mb-2">欢迎使用 CHD Renderer</h1>
               <p className="text-text-secondary">请从左侧选择文档进行预览。</p>
             </div>
             {/* ThemeSwitcher removed from homepage as requested */}
          </header>
          
          {/* Main content area left empty as requested */}
          <div className="min-h-[200px] flex flex-col gap-4 items-center justify-center text-text-secondary/50 border-2 border-dashed border-border-soft rounded-xl">
             <p className="text-lg">请点击左侧文档列表开始编辑</p>
             <p className="text-sm opacity-70">支持实时预览与智能编辑</p>
          </div>
        </div>
      </div>
    </div>
  );
}
