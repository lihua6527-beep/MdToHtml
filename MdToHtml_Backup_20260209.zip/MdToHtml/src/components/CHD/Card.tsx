'use client';

import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import 'katex/dist/katex.min.css';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { Maximize2, Palette, MoreHorizontal, LayoutGrid, Type, ArrowLeft, ArrowRight, ArrowUp, ArrowDown, Edit, Check, Trash2, GripHorizontal, GripVertical, Minus, Plus, AlignLeft, AlignCenter, AlignRight } from 'lucide-react';

// --- Types ---

type CardStyle = 'normal' | 'highlight' | 'stat' | 'quote' | 'warning' | 'code' | 'summary';

interface CardProps {
  title: string;
  content: string;
  style?: CardStyle;
  attributes?: Record<string, any>;
  colSpan?: number;
  rowSpan?: number;
  isActive?: boolean;
  isSelected?: boolean;
  onSelect?: () => void;
  onClick?: () => void;
  editMode?: boolean;
  onAttributeChange?: (attributes: Record<string, any>) => void;
  onContentChange?: (newContent: string) => void;
  onTitleChange?: (newTitle: string) => void;
  onMove?: (direction: 'left' | 'right' | 'up' | 'down') => void;
  onDelete?: () => void;
}

// --- Constants ---
const STYLE_LABELS: Record<CardStyle, string> = {
  normal: '标准',
  highlight: '高亮',
  stat: '指标',
  quote: '引用',
  warning: '警告',
  code: '代码',
  summary: '摘要'
};

const TEXT_SIZES = ['text-xs', 'text-sm', 'text-base', 'text-lg', 'text-xl', 'text-2xl', 'text-3xl', 'text-4xl', 'text-5xl'];

// --- Component: Card ---

export const Card: React.FC<CardProps> = ({ 
  title, 
  content, 
  style = 'normal',
  attributes = {},
  colSpan = 1, 
  rowSpan = 1, 
  isActive, 
  isSelected,
  onSelect,
  onClick, 
  editMode,
  onAttributeChange,
  onContentChange,
  onTitleChange,
  onMove,
  onDelete
}) => {
  const [isEditingContent, setIsEditingContent] = useState(false);
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [tempContent, setTempContent] = useState(content);
  const [tempTitle, setTempTitle] = useState(title);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const titleInputRef = useRef<HTMLInputElement>(null);

  // --- Dock Dragging State ---
  const [dockPosition, setDockPosition] = useState<{x: number, y: number} | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{x: number, y: number} | null>(null);
  const dockRef = useRef<HTMLDivElement>(null);

  // Font Sizes & Alignment
  const titleSize = attributes['title-size'] || (style === 'stat' ? 'text-4xl' : 'text-2xl');
  const contentSize = attributes['content-size'] || (style === 'stat' ? 'text-sm' : 'text-base');
  const titleAlign = attributes['title-align'] || 'center';
  const contentAlign = attributes['content-align'] || 'left';

  const adjustFontSize = (target: 'title' | 'content', direction: 'up' | 'down') => {
    const currentSize = target === 'title' ? titleSize : contentSize;
    const currentIndex = TEXT_SIZES.indexOf(currentSize);
    let nextIndex = currentIndex;
    
    if (currentIndex === -1) {
      // If not found, default to base/2xl then adjust
      nextIndex = target === 'title' ? 5 : 2;
    }

    if (direction === 'up') {
      nextIndex = Math.min(nextIndex + 1, TEXT_SIZES.length - 1);
    } else {
      nextIndex = Math.max(nextIndex - 1, 0);
    }

    onAttributeChange?.({ [`${target}-size`]: TEXT_SIZES[nextIndex] });
  };

  const setAlignment = (target: 'title' | 'content', align: 'left' | 'center' | 'right') => {
    onAttributeChange?.({ [`${target}-align`]: align });
  };

  useEffect(() => {
    setTempContent(content);
  }, [content]);

  useEffect(() => {
    setTempTitle(title);
  }, [title]);

  useEffect(() => {
    if (isEditingContent && textareaRef.current) {
        // Auto-resize on init
        textareaRef.current.style.height = 'auto';
        textareaRef.current.style.height = textareaRef.current.scrollHeight + 'px';
        textareaRef.current.focus();
    }
  }, [isEditingContent]);

  useEffect(() => {
    if (isEditingTitle && titleInputRef.current) {
        titleInputRef.current.focus();
    }
  }, [isEditingTitle]);

  // --- Dragging Logic ---
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || !dragStartRef.current) return;
      
      const dx = e.clientX - dragStartRef.current.x;
      const dy = e.clientY - dragStartRef.current.y;
      
      setDockPosition(prev => {
        const currentX = prev ? prev.x : (window.innerWidth / 2);
        const currentY = prev ? prev.y : (window.innerHeight - 100); // approx bottom-8
        return {
          x: currentX + dx,
          y: currentY + dy
        };
      });
      
      dragStartRef.current = { x: e.clientX, y: e.clientY };
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      dragStartRef.current = null;
    };

    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging]);

  const handleMouseDown = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsDragging(true);
    dragStartRef.current = { x: e.clientX, y: e.clientY };
    
    // Initialize dockPosition if it's null (first drag)
    if (!dockPosition && dockRef.current) {
       const rect = dockRef.current.getBoundingClientRect();
       setDockPosition({
         x: rect.left + rect.width / 2, // center point
         y: rect.top
       });
    }
  };

  const handleContentSave = (e?: React.MouseEvent) => {
      e?.stopPropagation();
      setIsEditingContent(false);
      if (tempContent !== content) {
          onContentChange?.(tempContent);
      }
  };

  const handleTitleSave = (e?: React.FormEvent) => {
      e?.preventDefault();
      e?.stopPropagation();
      setIsEditingTitle(false);
      if (tempTitle !== title) {
          // Remove potential leading ### if user typed them, or just send as is
          // The hook adds ### back.
          // Let's strip ### from tempTitle if present to avoid duplication
          const cleanTitle = tempTitle.replace(/^#+\s*/, '');
          onTitleChange?.(cleanTitle);
      }
  };

  const handleCardClick = (e: React.MouseEvent) => {
      if (editMode) {
          e.stopPropagation();
          onSelect?.();
      } else {
          onClick?.();
      }
  };

  // 1. Height Logic: 'h-full' to ensure cards in the same row stretch to equal height.
  const baseClasses = "rounded-card transition-all duration-300 hover:shadow-card flex flex-col overflow-hidden h-full cursor-pointer relative group";
  
  // 2. Color Logic (Theme Optimized)
  const styleVariants: Record<CardStyle, string> = {
    // Normal: Clean background, soft border
    normal: "bg-bg-card shadow-sm border border-border-soft hover:shadow-md text-text-primary",
    
    // Highlight: Distinct background, secondary accent
    highlight: "bg-bg-card-highlight shadow-sm border border-secondary/20 hover:border-secondary/40 text-text-primary",
    
    // Stat: Centered, bold, clean background
    stat: "bg-bg-card shadow-sm border border-border-soft text-center justify-center items-center py-6 text-text-primary",
    
    // Quote: Left accent, soft background
    quote: "bg-bg-card-highlight shadow-sm border-l-[4px] border-l-secondary text-text-secondary italic",
    
    // Warning: Soft red tint
    warning: "bg-accent/10 shadow-sm border border-accent/20 text-accent",
    
    // Code: Monospace, darker/distinct background
    code: "bg-gray-100 shadow-inner text-text-secondary font-mono text-sm border border-gray-200",
    
    // Summary: Full width, primary tint
    summary: "bg-primary/5 shadow-sm border border-primary/10 w-full text-text-primary",
  };

  const activeClass = isActive ? "ring-2 ring-primary ring-offset-2 transform scale-[1.02]" : "";
  const selectedClass = isSelected ? "ring-2 ring-secondary ring-offset-2 z-10" : "";

  const spanClasses = clsx({
    'col-span-1': colSpan === 1,
    'col-span-2': colSpan === 2,
    'col-span-3': colSpan === 3,
    'col-span-full': colSpan >= 4,
    'md:col-span-2': colSpan === 2,
    'md:col-span-3': colSpan === 3,
    'md:col-span-full': colSpan >= 4,
    'row-span-1': rowSpan === 1,
    'row-span-2': rowSpan === 2,
  });

  const isWide = colSpan && colSpan >= 2;
  const isWideAndShort = isWide && content.length < 100 && style === 'normal';

  return (
    <div 
      className={twMerge(baseClasses, styleVariants[style], spanClasses, activeClass, selectedClass)}
      onClick={handleCardClick}
    >
      {/* Floating Dock - Global Property Panel */}
      {editMode && isSelected && !isEditingContent && (
        <div 
            ref={dockRef}
            className="fixed z-50 animate-in slide-in-from-bottom-10 fade-in duration-300"
            style={{
                left: dockPosition ? dockPosition.x : '50%',
                top: dockPosition ? dockPosition.y : undefined,
                bottom: dockPosition ? undefined : '2rem',
                transform: dockPosition ? 'translate(-50%, 0)' : 'translate(-50%, 0)'
            }}
        >
          <div className="bg-bg-card/90 backdrop-blur-md shadow-2xl border border-border-soft rounded-2xl p-4 flex items-center gap-6 text-sm">
            
            {/* Drag Handle */}
            <div 
                className="cursor-move text-text-muted hover:text-text-primary px-1"
                onMouseDown={handleMouseDown}
            >
                <GripVertical size={20} />
            </div>

            {/* 1. Actions - Expanded Layout */}
            <div className="flex items-center gap-4 border-r border-border-soft pr-6">
               <div className="flex gap-2">
                   {/* Vertical Moves */}
                   <div className="flex flex-col gap-1">
                        <button onClick={(e) => { e.stopPropagation(); onMove?.('up'); }} className="p-1.5 hover:bg-primary/10 rounded-md text-text-secondary hover:text-primary transition-colors" title="上移"><ArrowUp size={16} /></button>
                        <button onClick={(e) => { e.stopPropagation(); onMove?.('down'); }} className="p-1.5 hover:bg-primary/10 rounded-md text-text-secondary hover:text-primary transition-colors" title="下移"><ArrowDown size={16} /></button>
                   </div>
                   {/* Horizontal Moves */}
                   <div className="flex flex-col gap-1">
                        <button onClick={(e) => { e.stopPropagation(); onMove?.('left'); }} className="p-1.5 hover:bg-primary/10 rounded-md text-text-secondary hover:text-primary transition-colors" title="左移"><ArrowLeft size={16} /></button>
                        <button onClick={(e) => { e.stopPropagation(); onMove?.('right'); }} className="p-1.5 hover:bg-primary/10 rounded-md text-text-secondary hover:text-primary transition-colors" title="右移"><ArrowRight size={16} /></button>
                   </div>
               </div>
               
               <div className="h-8 w-px bg-border-soft mx-1" /> {/* Divider */}

               <div className="flex gap-2">
                 <button onClick={(e) => { e.stopPropagation(); setIsEditingContent(true); }} className="flex flex-col items-center justify-center p-2 hover:bg-primary/10 rounded-md text-text-secondary hover:text-primary transition-colors gap-1" title="编辑内容">
                    <Edit size={18} />
                    <span className="text-[10px]">编辑</span>
                 </button>
                 <button onClick={(e) => { e.stopPropagation(); if(confirm('确认删除?')) onDelete?.(); }} className="flex flex-col items-center justify-center p-2 hover:bg-red-50 rounded-md text-text-secondary hover:text-red-500 transition-colors gap-1" title="删除">
                    <Trash2 size={18} />
                    <span className="text-[10px]">删除</span>
                 </button>
               </div>
            </div>

            {/* 2. Style Selector */}
            <div className="flex flex-col gap-2 border-r border-border-soft pr-6 min-w-[200px]">
               <span className="text-xs font-bold text-text-muted uppercase tracking-wider">卡片样式</span>
               <div className="flex flex-wrap gap-1.5">
                  {(['normal', 'highlight', 'stat', 'quote', 'warning', 'code', 'summary'] as CardStyle[]).map(s => (
                      <button
                         key={s}
                         onClick={(e) => { e.stopPropagation(); onAttributeChange?.({ 'card-style': s }); }}
                         className={clsx(
                            "px-2.5 py-1 rounded-full text-xs font-medium border transition-all",
                            s === style 
                                ? "bg-primary text-white border-primary shadow-sm" 
                                : "bg-bg-page text-text-secondary border-border-soft hover:border-primary/50 hover:text-primary"
                         )}
                      >
                         {STYLE_LABELS[s]}
                      </button>
                  ))}
               </div>
            </div>

            {/* 3. Typography & Alignment Controls */}
            <div className="flex flex-col gap-2 border-r border-border-soft pr-6">
                <span className="text-xs font-bold text-text-muted uppercase tracking-wider">排版调整</span>
                <div className="flex flex-col gap-2">
                    {/* Title Controls */}
                    <div className="flex items-center gap-3">
                        <span className="text-text-secondary text-xs w-6">标题</span>
                        {/* Size */}
                        <div className="flex items-center bg-bg-page rounded-lg border border-border-soft overflow-hidden h-6">
                            <button onClick={(e) => { e.stopPropagation(); adjustFontSize('title', 'down'); }} className="px-1.5 hover:bg-primary/5 text-text-secondary h-full flex items-center"><Minus size={10} /></button>
                            <span className="w-6 text-center text-[10px] font-mono leading-none">{TEXT_SIZES.indexOf(titleSize)}</span>
                            <button onClick={(e) => { e.stopPropagation(); adjustFontSize('title', 'up'); }} className="px-1.5 hover:bg-primary/5 text-text-secondary h-full flex items-center"><Plus size={10} /></button>
                        </div>
                        {/* Alignment */}
                        <div className="flex items-center bg-bg-page rounded-lg border border-border-soft overflow-hidden h-6">
                            <button onClick={(e) => { e.stopPropagation(); setAlignment('title', 'left'); }} className={clsx("px-1.5 h-full flex items-center transition-colors", titleAlign === 'left' ? "bg-primary/10 text-primary" : "text-text-muted hover:bg-primary/5")}><AlignLeft size={12} /></button>
                            <div className="w-px h-3 bg-border-soft" />
                            <button onClick={(e) => { e.stopPropagation(); setAlignment('title', 'center'); }} className={clsx("px-1.5 h-full flex items-center transition-colors", titleAlign === 'center' ? "bg-primary/10 text-primary" : "text-text-muted hover:bg-primary/5")}><AlignCenter size={12} /></button>
                        </div>
                    </div>
                    
                    {/* Content Controls */}
                    <div className="flex items-center gap-3">
                        <span className="text-text-secondary text-xs w-6">正文</span>
                        {/* Size */}
                        <div className="flex items-center bg-bg-page rounded-lg border border-border-soft overflow-hidden h-6">
                            <button onClick={(e) => { e.stopPropagation(); adjustFontSize('content', 'down'); }} className="px-1.5 hover:bg-primary/5 text-text-secondary h-full flex items-center"><Minus size={10} /></button>
                            <span className="w-6 text-center text-[10px] font-mono leading-none">{TEXT_SIZES.indexOf(contentSize)}</span>
                            <button onClick={(e) => { e.stopPropagation(); adjustFontSize('content', 'up'); }} className="px-1.5 hover:bg-primary/5 text-text-secondary h-full flex items-center"><Plus size={10} /></button>
                        </div>
                        {/* Alignment */}
                        <div className="flex items-center bg-bg-page rounded-lg border border-border-soft overflow-hidden h-6">
                            <button onClick={(e) => { e.stopPropagation(); setAlignment('content', 'left'); }} className={clsx("px-1.5 h-full flex items-center transition-colors", contentAlign === 'left' ? "bg-primary/10 text-primary" : "text-text-muted hover:bg-primary/5")}><AlignLeft size={12} /></button>
                            <div className="w-px h-3 bg-border-soft" />
                            <button onClick={(e) => { e.stopPropagation(); setAlignment('content', 'center'); }} className={clsx("px-1.5 h-full flex items-center transition-colors", contentAlign === 'center' ? "bg-primary/10 text-primary" : "text-text-muted hover:bg-primary/5")}><AlignCenter size={12} /></button>
                        </div>
                    </div>
                </div>
            </div>

            {/* 4. Layout/Width */}
            <div className="flex flex-col gap-2">
                <span className="text-xs font-bold text-text-muted uppercase tracking-wider">宽度占比</span>
                <div className="flex items-center gap-1">
                    {[1, 2, 3, 4].map(span => (
                        <button 
                          key={span}
                          onClick={(e) => { e.stopPropagation(); onAttributeChange?.({ 'col-span': span }); }}
                          className={clsx(
                              "w-8 h-8 flex items-center justify-center rounded-lg border transition-all",
                              ((colSpan === span) || (span === 4 && colSpan && colSpan >= 4))
                                ? "bg-primary/10 border-primary text-primary"
                                : "bg-bg-page border-border-soft text-text-muted hover:border-primary/50 hover:text-primary"
                          )}
                          title={span === 4 ? "Full Width" : `${span} Columns`}
                        >
                           <span className="text-xs font-bold">{span === 4 ? 'Full' : `${span}x`}</span>
                        </button>
                    ))}
                </div>
            </div>

          </div>
        </div>
      )}

      {/* Header */}
      <div className={clsx(
        "px-6 pt-6 pb-3",
        style === 'stat' && "pb-0 pt-0", // Stat handles its own padding
        style === 'code' && "bg-black/5 border-b border-border-soft py-3",
        // Alignment classes
        titleAlign === 'center' && "text-center flex justify-center",
        titleAlign === 'left' && "text-left flex justify-start",
        // Overrides for specific styles or legacy logic
        isWideAndShort && "flex justify-center text-center", 
        // Note: We prioritize explicit user alignment over auto-alignment, 
        // but keep 'stat' style centered by default if not set.
        // Actually, styleVariants.stat has 'text-center' which might conflict.
        // Let's rely on the explicit titleAlign state.
        "flex-none" // Header shouldn't shrink
      )}>
        {isEditingTitle && editMode && isSelected ? (
             <form onSubmit={handleTitleSave} onClick={e => e.stopPropagation()} className="w-full">
                <input
                    ref={titleInputRef}
                    value={tempTitle.replace(/^#+\s*/, '')} // Show only text
                    onChange={(e) => setTempTitle(e.target.value)}
                    onBlur={handleTitleSave}
                    className={clsx(
                        "w-full bg-bg-page border border-primary rounded px-2 py-1 font-bold text-lg focus:outline-none",
                        titleAlign === 'center' ? "text-center" : "text-left"
                    )}
                    placeholder="Card Title"
                />
             </form>
        ) : (
            <h3 
              onClick={(e) => {
                  if (editMode && isSelected) {
                      e.stopPropagation();
                      setIsEditingTitle(true);
                  }
              }}
              className={clsx(
                "font-bold tracking-tight font-heading transition-all duration-200 w-full",
                // Typography based on Theme
                style === 'warning' && "text-accent",
                style === 'code' && "text-text-muted text-sm font-mono",
                style !== 'code' && style !== 'warning' && style !== 'stat' && "text-primary",
                style === 'stat' && "text-primary mb-2",
                // Dynamic Font Size
                titleSize,
                editMode && isSelected && "hover:bg-primary/5 cursor-text border border-transparent hover:border-primary/20 rounded px-1 -mx-1 transition-colors"
              )}
            >
              {title.replace('### ', '')}
            </h3>
        )}
      </div>
      
      {/* Content */}
      <div className={clsx(
        "px-6 pb-6 pt-0 flex-grow font-body leading-relaxed relative transition-all duration-200",
        // Dynamic Content Font Size
        contentSize,
        // Alignment
        contentAlign === 'center' && "text-center",
        contentAlign === 'left' && "text-left",
        
        style === 'stat' && "pt-0 pb-6 text-text-muted font-medium uppercase tracking-wide",
        style === 'code' && "p-4 overflow-x-auto text-sm", 
        style === 'quote' && "pt-3",
        isWideAndShort && "flex justify-center items-center pt-0 text-center",
        isWide && !isWideAndShort && "flex flex-col" 
      )}>
        {isEditingContent ? (
            <div className="w-full h-auto min-h-full relative z-30" onClick={e => e.stopPropagation()}>
                <textarea
                    ref={textareaRef}
                    value={tempContent}
                    onChange={(e) => {
                        setTempContent(e.target.value);
                        e.target.style.height = 'auto';
                        e.target.style.height = e.target.scrollHeight + 'px';
                    }}
                    className={clsx(
                        "w-full bg-bg-page border border-primary rounded resize-none font-mono focus:outline-none focus:ring-1 focus:ring-primary overflow-hidden",
                        "p-2", // Consistent padding
                        contentAlign === 'center' ? "text-center" : "text-left"
                    )}
                    placeholder="Enter markdown..."
                />
                <button 
                    onClick={handleContentSave}
                    className="absolute bottom-2 right-2 p-1 bg-primary text-primary-foreground rounded-full shadow-lg hover:bg-primary/90 transition-colors z-40"
                >
                    <Check size={16} />
                </button>
            </div>
        ) : (
            <div 
                onClick={(e) => {
                    if (editMode && isSelected) {
                        e.stopPropagation();
                        setIsEditingContent(true);
                    }
                }}
                className={clsx(
                    "w-full h-full",
                    editMode && isSelected && "hover:bg-primary/5 cursor-text border border-transparent hover:border-primary/20 rounded p-1 -m-1 transition-colors",
                    isWide && !isWideAndShort && "max-w-3xl w-full"
                )}
            >
                {style === 'code' ? (
                <pre className="whitespace-pre-wrap font-mono text-sm">{content}</pre>
                ) : (
                <ReactMarkdown 
                    remarkPlugins={[remarkGfm, remarkMath]}
                    rehypePlugins={[rehypeKatex]}
                    components={{
                    // Custom styling for markdown elements to match theme
                    p: ({node, ...props}) => <p className="mb-2 last:mb-0" {...props} />,
                    ul: ({node, ...props}) => <ul className="list-disc pl-4 mb-2 space-y-1 text-left" {...props} />, // Lists usually look better left aligned
                    ol: ({node, ...props}) => <ol className="list-decimal pl-4 mb-2 space-y-1 text-left" {...props} />,
                    a: ({node, ...props}) => <a className="text-primary hover:underline" {...props} />,
                    strong: ({node, ...props}) => <strong className="font-bold text-text-primary" {...props} />,
                    code: ({node, ...props}) => <code className="bg-bg-page px-1.5 py-0.5 rounded text-sm font-mono text-text-secondary" {...props} />
                    }}
                >
                    {content}
                </ReactMarkdown>
                )}
            </div>
        )}
      </div>
    </div>
  );
};
