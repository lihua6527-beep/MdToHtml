'use client';

import React from 'react';
import { Card } from './Card';

// --- Types ---

import { Plus, LayoutGrid, Columns } from 'lucide-react';

interface SectionProps {
  title: string;
  cards: Array<{
    title: string;
    content: string;
    props: Record<string, any>;
    startLine?: number;
    endLine?: number;
    blockIndex?: number;
  }>;
  layoutProps: Record<string, any>;
  blockIndex?: number;
  activeLine?: number;
  onCardClick?: (line: number) => void;
  editMode?: boolean;
  selectedBlockIndex?: number | null;
  onSelectBlock?: (index: number | null) => void;
  onCardUpdate?: (blockIndex: number, newAttrs: Record<string, any>) => void;
  onContentUpdate?: (cardIndex: number, newContent: string) => void;
  onTitleUpdate?: (cardIndex: number, newTitle: string) => void;
  onCardMove?: (cardIndex: number, direction: 'left' | 'right' | 'up' | 'down') => void;
  onCardDelete?: (cardIndex: number) => void;
  onCardAdd?: (sectionBlockIndex: number) => void;
}

// --- Component: Section ---

export const Section: React.FC<SectionProps> = ({ 
  title, 
  cards, 
  layoutProps, 
  blockIndex,
  activeLine, 
  onCardClick, 
  editMode, 
  selectedBlockIndex,
  onSelectBlock,
  onCardUpdate,
  onContentUpdate,
  onTitleUpdate,
  onCardMove,
  onCardDelete,
  onCardAdd
}) => {
  // [Fix: Default to Grid System]
  // User requested "Multidimensional Layout" as default.
  // We default to GRID (cols-2) to enable side-by-side rhythm unless explicitly 'list' or 'stack'.
  const isList = layoutProps.layout === 'list' || layoutProps.layout === 'stack';
  const isGrid = !isList;

  // Determine Column Count
  let columns = 2; // Default to 2 for that "Bento" feel
  if (layoutProps.columns) {
    columns = parseInt(layoutProps.columns, 10);
  } else if (layoutProps.layout === 'gallery') {
    columns = 3;
  } else if (layoutProps.layout === 'stat-row') {
    columns = 4;
  }

  // [Fix 5: Explicit Grid Columns]
  const gridColsMap: Record<number, string> = {
    1: 'md:grid-cols-1',
    2: 'md:grid-cols-2',
    3: 'md:grid-cols-3',
    4: 'md:grid-cols-4',
    5: 'md:grid-cols-5',
    6: 'md:grid-cols-6',
  };
  
  const colClass = gridColsMap[columns] || 'md:grid-cols-2';

  // Use 'items-stretch' (default) instead of 'items-start' so cards in same row have equal height
  const containerClasses = isGrid 
    ? `grid grid-cols-1 ${colClass} gap-6 grid-flow-dense auto-rows-min` 
    : 'flex flex-col gap-6';

  const handleLayoutChange = () => {
    if (!blockIndex) return;
    
    // Cycle: 2 -> 3 -> 4 -> 1 -> 2
    let nextCols = 2;
    if (columns === 2) nextCols = 3;
    else if (columns === 3) nextCols = 4;
    else if (columns === 4) nextCols = 1;
    else nextCols = 2;
    
    onCardUpdate?.(blockIndex, { ...layoutProps, columns: String(nextCols) });
  };

  return (
    <section className="animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex items-center gap-4 mb-6">
        <h2 className="text-2xl font-bold text-text-primary tracking-tight">{title.replace('## ', '')}</h2>
        {editMode && (
             <div className="flex items-center gap-2">
                 <button
                    onClick={() => blockIndex !== undefined && onCardAdd?.(blockIndex)}
                    className="w-8 h-8 flex items-center justify-center rounded-md bg-primary/5 border border-primary/20 text-primary hover:bg-primary/10 hover:shadow-sm transition-all"
                    title="Add New Card"
                 >
                    <Plus size={18} strokeWidth={2.5} />
                 </button>
                 
                 <button
                    onClick={handleLayoutChange}
                    className="w-8 h-8 flex items-center justify-center rounded-md bg-bg-card border border-border-soft text-text-secondary hover:text-primary hover:border-primary/50 transition-all"
                    title={`Change Layout (Current: ${columns} Cols)`}
                 >
                    {columns === 1 ? <LayoutGrid size={16} /> : <Columns size={16} />}
                 </button>
             </div>
        )}
      </div>
      
      <div className={containerClasses}>
        {cards.map((card, idx) => {
          const isActive = activeLine !== undefined && card.startLine !== undefined && card.endLine !== undefined 
            ? (activeLine >= card.startLine && activeLine <= card.endLine)
            : false;
            
          const isSelected = selectedBlockIndex !== undefined && selectedBlockIndex !== null && card.blockIndex === selectedBlockIndex;

          return (
            <Card 
              key={idx}
              title={card.title}
              content={card.content}
              style={card.props['card-style']}
              attributes={card.props}
              colSpan={card.props['col-span'] ? parseInt(card.props['col-span']) : undefined}
              rowSpan={card.props['row-span'] ? parseInt(card.props['row-span']) : undefined}
              isActive={isActive}
              isSelected={isSelected}
              onSelect={() => card.blockIndex !== undefined && onSelectBlock?.(card.blockIndex)}
              onClick={() => card.startLine !== undefined && onCardClick?.(card.startLine)}
              editMode={editMode}
              onAttributeChange={(newAttrs) => card.blockIndex !== undefined && onCardUpdate?.(card.blockIndex, newAttrs)}
              onContentChange={(newContent) => card.blockIndex !== undefined && onContentUpdate?.(card.blockIndex, newContent)}
              onTitleChange={(newTitle) => card.blockIndex !== undefined && onTitleUpdate?.(card.blockIndex, newTitle)}
              onMove={(direction) => card.blockIndex !== undefined && onCardMove?.(card.blockIndex, direction)}
              onDelete={() => card.blockIndex !== undefined && onCardDelete?.(card.blockIndex)}
            />
          );
        })}
      </div>

      {/* Divider between sections */}
      <hr className="mt-8 mb-8 border-t border-border-soft" />
    </section>
  );
};
