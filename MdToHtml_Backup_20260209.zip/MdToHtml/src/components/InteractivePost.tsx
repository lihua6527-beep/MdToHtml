'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import { ChevronLeft, Edit, Save, Eye, Layout, ArrowLeft, CheckCircle, AlertTriangle } from 'lucide-react';
import { CHDRenderer } from '@/components/CHD/CHDRenderer';
import { useMarkdownInteraction } from '@/hooks/useMarkdownInteraction';
import { Button } from '@/components/ui/button';
import { ThemeSwitcher } from '@/components/ThemeSwitcher';
import { parseCHDBlocks } from '@/lib/chdParser';
import { RuleBasedScorer } from '@/lib/scorer';
import { ScoreResponse } from '@/types/model-interface';

interface InteractivePostProps {
  initialContent: string;
  slug: string;
  decodedSlug: string;
}

const InteractivePost: React.FC<InteractivePostProps> = ({ initialContent, slug, decodedSlug }) => {
  const [content, setContent] = useState(initialContent);
  const [isEditing, setIsEditing] = useState(false);
  const [selectedBlockIndex, setSelectedBlockIndex] = useState<number | null>(null);
  const { updateAttribute, updateContent, updateTitle, moveCard, deleteCard, addCard, undo, canUndo, operationLog } = useMarkdownInteraction(content, setContent);
  const [isSaving, setIsSaving] = useState(false);
  
  // Real-time Scoring
  const [scoreResult, setScoreResult] = useState<ScoreResponse | null>(null);

  // Evaluate on initial load and content change
  useEffect(() => {
    // Only evaluate if content is present
    if (content) {
       const result = RuleBasedScorer.evaluate(content);
       setScoreResult(result);
    }
  }, [content]);

  // Clear selection when exiting edit mode
  React.useEffect(() => {
    if (!isEditing) {
        setSelectedBlockIndex(null);
    }
  }, [isEditing]);

  const handleSave = async () => {
     setIsSaving(true);
     try {
        // Save to file (local dev) and Archive Session
        const res = await fetch('/api/save-session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                slug: decodedSlug, 
                input: initialContent,
                output: content,
                operations: operationLog
            })
        });

        if (res.ok) {
            // Also update the live file for hot reload if needed (optional, but good for dev)
            // The previous logic used /api/save. We can keep it or assume save-session does it?
            // save-session saves to data/ folder. It does NOT update the source file in content/.
            // We should PROBABLY also update the source file if the user expects "Save" to mean "Update my site".
            // The user request emphasizes "saving input/output/ops in data folder".
            // But if I stop updating the actual content file, the edits won't persist on the site?
            // I should probably do BOTH.
            
            await fetch('/api/save', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ slug: decodedSlug, content })
            });

            alert('保存并归档成功');
            setIsEditing(false);
        } else {
            alert('保存失败');
        }
     } catch(e) {
        console.error(e);
        alert('保存请求出错');
     } finally {
        setIsSaving(false);
     }
  };

  return (
    <div className="flex flex-col min-h-screen">
       {/* Navigation Header */}
       <div className="sticky top-0 z-50 h-14 bg-bg-card/80 backdrop-blur-md border-b border-border-soft flex items-center px-4 justify-between shadow-sm print:hidden">
          <div className="flex items-center gap-4">
              <Link 
                href="/"
                className="flex items-center gap-1 text-sm font-medium text-text-secondary hover:text-primary transition-colors px-3 py-1.5 rounded-md hover:bg-secondary/20"
              >
                <ChevronLeft className="w-4 h-4" />
                返回首页
              </Link>
              
              <div className="h-4 w-px bg-border-soft/50" />
              <ThemeSwitcher />
              
              {/* Score Indicator */}
              {scoreResult && (
                <div className="flex items-center gap-2 ml-4 px-3 py-1 rounded-full bg-secondary/10 border border-border-soft">
                   {scoreResult.totalScore >= 90 ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                   ) : (
                      <AlertTriangle className="w-4 h-4 text-yellow-500" />
                   )}
                   <span className={`text-sm font-semibold ${
                       scoreResult.totalScore >= 90 ? 'text-green-600' : 'text-yellow-600'
                   }`}>
                      {scoreResult.totalScore}分
                   </span>
                   {scoreResult.issues.length > 0 && (
                      <span className="text-xs text-text-secondary ml-1">
                         ({scoreResult.issues.length} 个问题)
                      </span>
                   )}
                </div>
              )}

              {/* Undo Button - Top Left Area */}
              {isEditing && (
                  <Button
                    onClick={undo}
                    disabled={!canUndo}
                    variant="ghost"
                    size="sm"
                    className="gap-2 text-text-secondary hover:text-primary disabled:opacity-30"
                    title="撤销 (Undo)"
                  >
                    <ArrowLeft className="w-4 h-4" /> 撤销
                  </Button>
              )}
          </div>
          
          <div className="text-sm font-bold text-text-primary truncate max-w-md absolute left-1/2 -translate-x-1/2">
             {decodedSlug}
          </div>

          <div className="flex items-center gap-2">
            {isEditing ? (
                <>
                    <Button 
                        onClick={() => setIsEditing(false)} 
                        variant="ghost" 
                        size="sm"
                        className="gap-2 text-text-secondary"
                    >
                        <Eye size={14} /> 取消/预览
                    </Button>
                    <Button 
                        onClick={handleSave} 
                        variant="default" 
                        size="sm"
                        className="gap-2"
                        disabled={isSaving}
                    >
                        <Save size={14} /> {isSaving ? '保存中...' : '保存修改'}
                    </Button>
                </>
            ) : (
                <Button 
                    onClick={() => setIsEditing(true)} 
                    variant="outline" 
                    size="sm"
                    className="gap-2"
                >
                    <Edit size={14} /> 编辑页面
                </Button>
            )}
          </div>
       </div>

       {/* Content */}
       <div className="flex-1">
          <CHDRenderer 
            markdown={content} 
            editMode={isEditing}
            selectedBlockIndex={selectedBlockIndex}
            onSelectBlock={setSelectedBlockIndex}
            onCardUpdate={(idx, attrs) => {
                Object.entries(attrs).forEach(([key, value]) => {
                    updateAttribute(idx, key, value);
                });
            }}
            onContentUpdate={updateContent}
            onTitleUpdate={updateTitle}
            onCardMove={moveCard}
            onCardDelete={deleteCard}
            onCardAdd={addCard}
          />
       </div>
    </div>
  );
};

export default InteractivePost;
