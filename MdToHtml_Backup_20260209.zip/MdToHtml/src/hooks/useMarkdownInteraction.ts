import { useCallback, useState } from 'react';
import { parseCHDBlocks, CHDBlock } from '@/lib/chdParser';

export interface OperationLogEntry {
  type: string;
  args: any[];
  timestamp: number;
}

export interface MarkdownUpdater {
  updateAttribute: (blockIndex: number, key: string, value: any) => void;
  updateContent: (blockIndex: number, newContent: string) => void;
  updateTitle: (blockIndex: number, newTitle: string) => void;
  moveCard: (blockIndex: number, direction: 'left' | 'right' | 'up' | 'down') => void;
  deleteCard: (blockIndex: number) => void;
  addCard: (sectionBlockIndex: number) => void;
  undo: () => void;
  canUndo: boolean;
  operationLog: OperationLogEntry[];
}

export function useMarkdownInteraction(
  markdown: string,
  onUpdate: (newMarkdown: string) => void
): MarkdownUpdater {
  // Simple history stack for undo
  const [history, setHistory] = useState<string[]>([]);
  const [operationLog, setOperationLog] = useState<OperationLogEntry[]>([]);
  
  // Wrapper for onUpdate to push to history
  const pushToHistory = useCallback((currentContent: string) => {
     setHistory(prev => [...prev, currentContent]);
  }, []);

  const logOperation = useCallback((type: string, ...args: any[]) => {
      setOperationLog(prev => [...prev, { type, args, timestamp: Date.now() }]);
  }, []);

  const undo = useCallback(() => {
     setHistory(prev => {
         if (prev.length === 0) return prev;
         const newHistory = [...prev];
         const previousState = newHistory.pop();
         if (previousState !== undefined) {
             onUpdate(previousState);
             logOperation('undo');
         }
         return newHistory;
     });
  }, [onUpdate, logOperation]);

  const canUndo = history.length > 0;

  // We need to wrap the internal onUpdate calls to save history first.
  const handleUpdate = useCallback((newContent: string) => {
      pushToHistory(markdown);
      onUpdate(newContent);
  }, [markdown, onUpdate, pushToHistory]);

  // Helper to replace a line
  const replaceLine = (lines: string[], lineIndex: number, regex: RegExp, replacer: (match: RegExpMatchArray) => string) => {
    // ... (helper implementation same as before)
    if (lineIndex < 0 || lineIndex >= lines.length) return lines;
    const line = lines[lineIndex];
    const match = line.match(regex);
    if (match) {
      lines[lineIndex] = replacer(match);
    } else {
        if (!line.includes('{')) {
            lines[lineIndex] = `${line.trim()} {${replacer(['', ''] as any)}}`; 
        } else {
             // Simple append for now
        }
    }
    return lines;
  };

  const updateTitle = useCallback((blockIndex: number, newTitle: string) => {
    logOperation('updateTitle', blockIndex, newTitle);
    const blocks = parseCHDBlocks(markdown);
    const block = blocks[blockIndex];
    if (!block) return;

    const lines = markdown.split('\n');
    const lineIndex = block.startLine;
    let line = lines[lineIndex];

    // Preserve attributes
    const attrMatch = line.match(/\{[^}]+\}/);
    const attrs = attrMatch ? attrMatch[0] : '';
    
    // Construct new header
    // Assuming level is determined by '#' count
    const levelMatch = line.match(/^(#+)\s/);
    const level = levelMatch ? levelMatch[1] : '###'; // Default to h3 if unknown
    
    lines[lineIndex] = `${level} ${newTitle} ${attrs}`;
    
    handleUpdate(lines.join('\n'));
  }, [markdown, handleUpdate]);

  const updateAttribute = useCallback((blockIndex: number, key: string, value: any) => {
    logOperation('updateAttribute', blockIndex, key, value);
    const blocks = parseCHDBlocks(markdown);
    const block = blocks[blockIndex]; // Note: index must match blocks array order
    if (!block) return;

    const lines = markdown.split('\n');
    const lineIndex = block.startLine;
    let line = lines[lineIndex];

    // Check if attributes exist
    const attrMatch = line.match(/\{([^}]+)\}/);
    let attrs: Record<string, string> = {};
    let prefix = line;

    if (attrMatch) {
      prefix = line.replace(/\{[^}]+\}/, '').trim();
      const attrStr = attrMatch[1];
      attrStr.split(',').forEach(pair => {
        const [k, v] = pair.split('=').map(s => s.trim());
        if (k) attrs[k] = v ? v.replace(/['"]/g, '') : '';
      });
    } else {
        prefix = line.trim();
    }

    // Update value
    attrs[key] = String(value);

    // Reconstruct string
    const attrString = Object.entries(attrs)
      .map(([k, v]) => `${k}=${v}`)
      .join(', ');
    
    lines[lineIndex] = `${prefix} {${attrString}}`;
    
    handleUpdate(lines.join('\n'));
  }, [markdown, handleUpdate, logOperation]);

  const updateContent = useCallback((blockIndex: number, newContent: string) => {
    logOperation('updateContent', blockIndex, newContent);
    const blocks = parseCHDBlocks(markdown);
    const block = blocks[blockIndex];
    if (!block) return;

    const lines = markdown.split('\n');
    
    // Replace content lines
    // block.startLine is title. content starts at startLine + 1
    // block.endLine is the last line of content
    
    const before = lines.slice(0, block.startLine + 1);
    const after = lines.slice(block.endLine + 1);
    
    // newContent might have multiple lines
    const newLines = newContent.split('\n');
    
    const result = [...before, ...newLines, ...after];
    handleUpdate(result.join('\n'));
  }, [markdown, handleUpdate, logOperation]);

  const moveCard = useCallback((blockIndex: number, direction: 'left' | 'right' | 'up' | 'down') => {
      logOperation('moveCard', blockIndex, direction);
      // Simplified: Swap with prev/next card in the same section
      // We need to identify siblings.
      const blocks = parseCHDBlocks(markdown);
      const block = blocks[blockIndex];
      if (!block || block.type !== 'card') return;

      // Find siblings in the same section
      // Sections start with ##
      // We can iterate blocks to find the section this card belongs to
      let sectionIndex = -1;
      let cardIndicesInThisSection: number[] = [];
      
      // Re-scan for siblings
      // Find the enclosing section range
      let sectionStartLine = -1;
      let sectionEndLine = Infinity;
      
      // Find section header before
      for (let i = blockIndex - 1; i >= 0; i--) {
          if (blocks[i].type === 'section') {
              sectionStartLine = blocks[i].startLine;
              break;
          }
      }
      
      // Find section header after
      for (let i = blockIndex + 1; i < blocks.length; i++) {
          if (blocks[i].type === 'section') {
              sectionEndLine = blocks[i].startLine;
              break;
          }
      }
      
      // Now gather all cards strictly between sectionStartLine and sectionEndLine
      cardIndicesInThisSection = blocks
          .map((b, idx) => ({ b, idx }))
          .filter(({ b }) => b.type === 'card' && b.startLine > sectionStartLine && b.startLine < sectionEndLine)
          .map(({ idx }) => idx);

      const currentPos = cardIndicesInThisSection.indexOf(blockIndex);
      if (currentPos === -1) return;

      let targetPos = -1;
      if (direction === 'left' || direction === 'up') {
          targetPos = currentPos - 1;
      } else {
          targetPos = currentPos + 1;
      }

      if (targetPos < 0 || targetPos >= cardIndicesInThisSection.length) return;

      const targetBlockIndex = cardIndicesInThisSection[targetPos];
      const targetBlock = blocks[targetBlockIndex];

      // Perform Swap
      const lines = markdown.split('\n');
      
      const firstIndex = Math.min(blockIndex, targetBlockIndex);
      const secondIndex = Math.max(blockIndex, targetBlockIndex);
      
      const firstBlock = blocks[firstIndex];
      const secondBlock = blocks[secondIndex];
      
      const chunk1 = lines.slice(firstBlock.startLine, firstBlock.endLine + 1);
      const chunk2 = lines.slice(secondBlock.startLine, secondBlock.endLine + 1);
      
      const middle = lines.slice(firstBlock.endLine + 1, secondBlock.startLine);
      
      const before = lines.slice(0, firstBlock.startLine);
      const after = lines.slice(secondBlock.endLine + 1);
      
      const newLines = [...before, ...chunk2, ...middle, ...chunk1, ...after];
      
      handleUpdate(newLines.join('\n'));

  }, [markdown, handleUpdate, logOperation]);

  const deleteCard = useCallback((blockIndex: number) => {
      logOperation('deleteCard', blockIndex);
      const blocks = parseCHDBlocks(markdown);
      const block = blocks[blockIndex];
      if (!block) return;

      const lines = markdown.split('\n');
      // Remove lines from startLine to endLine
      // Also maybe remove the preceding empty line if it exists to keep it clean?
      // For now, just remove the block lines.
      
      const before = lines.slice(0, block.startLine);
      const after = lines.slice(block.endLine + 1);
      
      handleUpdate([...before, ...after].join('\n'));
  }, [markdown, handleUpdate, logOperation]);

  const addCard = useCallback((sectionBlockIndex: number) => {
      logOperation('addCard', sectionBlockIndex);
      const blocks = parseCHDBlocks(markdown);
      const lines = markdown.split('\n');
      
      // If sectionBlockIndex is -1, we append to the end of the file or first implicit section
      // If valid index, we append at the end of that section
      
      let insertLine = lines.length;

      if (sectionBlockIndex >= 0 && sectionBlockIndex < blocks.length) {
          const sectionBlock = blocks[sectionBlockIndex];
          // Find the next section to define the boundary
          let nextSectionStart = lines.length;
          for (let i = sectionBlockIndex + 1; i < blocks.length; i++) {
              if (blocks[i].type === 'section') {
                  nextSectionStart = blocks[i].startLine;
                  break;
              }
          }
          insertLine = nextSectionStart;
      } else {
           // Implicit first section (Overview) or no sections
           // Find the first explicit section
           let firstSectionStart = lines.length;
           for (let i = 0; i < blocks.length; i++) {
               if (blocks[i].type === 'section') {
                   firstSectionStart = blocks[i].startLine;
                   break;
               }
           }
           insertLine = firstSectionStart;
      }

      // Check if we need to add a newline before
      const newCardTemplate = [
          "",
          "### New Card {col-span=1}",
          "Enter content here..."
      ];
      
      const before = lines.slice(0, insertLine);
      const after = lines.slice(insertLine);
      
      handleUpdate([...before, ...newCardTemplate, ...after].join('\n'));
  }, [markdown, handleUpdate, logOperation]);

  return { updateAttribute, updateContent, updateTitle, moveCard, deleteCard, addCard, undo, canUndo, operationLog };
}
