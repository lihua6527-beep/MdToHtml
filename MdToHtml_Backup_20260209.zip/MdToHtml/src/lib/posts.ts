import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';

// Use absolute path to ensure reliability across environments
// Assuming 'input' is at the project root level, same as 'MdToHtml'
const postsDirectory = path.join(process.cwd(), '../input');

export function getPostSlugs() {
  if (!fs.existsSync(postsDirectory)) {
    // Create directory if it doesn't exist to avoid errors
    try {
        fs.mkdirSync(postsDirectory, { recursive: true });
    } catch (e) {
        console.warn('Failed to create input directory:', e);
        return [];
    }
    return [];
  }
  
  // Return raw filenames. Next.js handles Unicode.
  return fs.readdirSync(postsDirectory).filter((file) => /\.md$/i.test(file));
}

export function getPostBySlug(slug: string) {
  const realSlug = slug.replace(/\.md$/i, '');
  const fullPath = path.join(postsDirectory, `${realSlug}.md`);
  
  if (!fs.existsSync(fullPath)) {
     // Case-insensitive fallback
     const dir = fs.readdirSync(postsDirectory);
     const match = dir.find(f => f.toLowerCase() === `${realSlug.toLowerCase()}.md`);
     if (match) {
         return { slug: realSlug, content: fs.readFileSync(path.join(postsDirectory, match), 'utf8') };
     }

     throw new Error(`File not found: ${fullPath}`);
  }

  const fileContents = fs.readFileSync(fullPath, 'utf8');
  return { slug: realSlug, content: fileContents };
}

export function getAllPosts() {
  const slugs = getPostSlugs();
  const posts = slugs.map((slug) => getPostBySlug(slug));
  return posts;
}
