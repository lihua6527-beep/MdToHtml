/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        bg: {
          page: 'var(--bg-page)',
          card: 'var(--bg-card)',
          'card-highlight': 'var(--bg-card-highlight)',
        },
        text: {
          primary: 'var(--text-primary)',
          secondary: 'var(--text-secondary)',
          muted: 'var(--text-muted)',
        },
        border: {
          soft: 'var(--border-soft)',
          highlight: 'var(--border-highlight)',
        },
        primary: {
          DEFAULT: 'var(--primary)',
          foreground: 'var(--primary-foreground)',
        },
        secondary: 'var(--secondary)',
        accent: 'var(--accent)',
        ring: 'var(--ring)',
        
        // Backwards compatibility for existing hardcoded classes (optional, can be phased out)
        morandi: {
          50: '#f7f7f5',
          800: '#464642',
          700: '#54544f',
        }
      },
      borderRadius: {
        card: 'var(--radius-card)',
      },
      boxShadow: {
        card: 'var(--shadow-card)',
      },
      fontFamily: {
        heading: 'var(--font-heading)',
        body: 'var(--font-body)',
      }
    },
  },
  plugins: [],
}
