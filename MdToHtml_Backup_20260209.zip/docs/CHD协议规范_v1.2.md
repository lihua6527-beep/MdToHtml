---
title: "CHD约束协议 (Card-based Hierarchical Document)"
subtitle: "面向人机协同的文档工程规范 DSL"
version: "1.3"
---

## 1. 协议概述

CHD (Card-based Hierarchical Document) 是一套专为降低 AI 理解成本并提升人类写作结构化程度而设计的文档工程协议。其核心理念是将非结构化的“文本流”转化为结构化的“语义卡片流”。

### 核心哲学
- **结构优先**：在有限的自由下，最大化机器可理解性。
- **刚性层级**：严格限制文档层级深度，禁止无限嵌套。
- **显式语义**：通过格式显式声明内容类型，而非依赖 AI 猜测。

## 核心亮点 (Best Practice Example) {layout="grid", columns=4}

### 三级刚性结构 {card-style="stat"}
Document > Section > Card

### 卡片化单元 {card-style="stat"}
最小语义处理单位

### 元数据驱动 {card-style="stat"}
YAML Frontmatter 定义全局属性

### AI友好设计 {card-style="stat"}
将解析复杂度降低99%

---

## 2. 文档结构定义 (L0-L3)

CHD 协议定义了严格的三级刚性结构，禁止四级及更深层级。

### L0: 文档根节点 (Document)
文档必须以 YAML Frontmatter 开头，定义元数据。

```yaml
---
title: "文档主标题"          # 必须，对应 L1 概念
subtitle: "副标题"           # 可选
tags: ["标签1", "标签2"]     # 可选
version: "1.3"               # 协议版本
---
```

> **变更注意 (v1.3)**: `highlights` 字段已废弃。请在正文第一个 Section 使用 `stat` 卡片组来展示核心亮点。

### L1: 章节节点 (Section)
使用二级标题 (`##`) 定义章节。章节是文档的逻辑分割单位。

**约束规则：**
- 必须使用 `## ` 开头。
- 标题文本应简洁，作为该逻辑块的核心总结。
- 章节下不能直接包含正文文本，必须包含 L2 卡片。
- 渲染时，章节标题下方会自动生成分割线。

### L2: 卡片节点 (Card)
使用三级标题 (`###`) 定义卡片。卡片是内容的最小语义单元。

**约束规则：**
- 必须使用 `### ` 开头。
- 标题即卡片名称。
- 卡片包含具体的内容块（文本、代码、列表、图表）。
- **禁止**在卡片内使用四级标题 (`####`)。
- 一个卡片对应一个独立的语义点（Concept, Example, Metric 等）。

### 结构示意图
```
[Document L0]
  ├── [Metadata]
  ├── [Section L1] "## 研究背景"
  │     ├── [Card L2] "### 传统方法局限" (Text)
  │     └── [Card L2] "### 核心洞察" (Text)
  ├── [Section L1] "## 实验结果"
  │     ├── [Card L2] "### 准确率对比" (Chart/Metric)
  │     └── [Card L2] "### 性能提升" (Data)
```

---

## 3. 扩展语法 DSL

为了支持更丰富的布局和语义，CHD 支持在标题后使用扩展属性语法 `{key="value"}`。

### 3.1 布局控制 (Layout)
应用于 Section (`##`)，控制其下 Cards 的排列方式。

```markdown
## 方法设计 {layout="2-column"}
## 实验结果 {layout="grid", columns=3}
```

### 3.2 卡片样式与形态 (Card Style & Shape)
应用于 Card (`###`)，定义卡片的视觉呈现语义和尺寸。

```markdown
### 核心性能 {card-style="stat", col-span=2}
### 用户评价 {card-style="quote", row-span=2}
### 移动端预览 {card-style="normal", width="narrow"}
```

**支持的样式类型 (`card-style`)：**
- `normal`: 默认文本卡片
- `highlight`: 高亮强调
- `stat`: 数据统计/大数字展示
- `quote`: 引用/评价
- `warning`: 警告/注意
- `code`: 纯代码展示
- `summary`: 综述/摘要（用于章节首部）

**支持的尺寸属性：**
- `col-span`: 跨列数 (Grid 布局下生效，如 `col-span=2`)
- `row-span`: 跨行数 (Grid 布局下生效，如 `row-span=2`)
- `width`: 宽度提示 (`wide` | `narrow` | `full`)

### 3.3 文本排版 (Typography) [v1.2 新增]
应用于 Card (`###`)，控制卡片内文本的对齐与大小。

```markdown
### 居中标题 {title-align="center", content-align="left"}
### 大号文本 {title-size="text-3xl", content-size="text-lg"}
```

**支持的排版属性：**
- `title-align`: 标题对齐方式 (`left` | `center` | `right`)，默认为 `center`。
- `content-align`: 内容对齐方式 (`left` | `center` | `right`)，默认为 `left`。
- `title-size`: 标题字号 (基于 Tailwind 标尺，如 `text-xl`, `text-2xl`...)。
- `content-size`: 内容字号 (基于 Tailwind 标尺，如 `text-sm`, `text-base`...)。

---

## 4. 禁止规则 (Strict Constraints)

为了保证 AI 解析的确定性，以下行为被严格禁止：

1.  **禁止四级标题**：`####` 及更深层级标题是非法的。如果需要更细粒度，请拆分为新的卡片或使用列表。
2.  **禁止孤儿文本**：`## Section` 下方必须紧跟 `### Card`，不允许在 `##` 和 `###` 之间直接书写正文。
3.  **禁止混合层级**：文档必须严格遵循 L0 -> L1 -> L2 的层级顺序。
4.120→4.  **禁止隐式结构**：不要使用粗体或字号大小来模拟标题，所有结构必须通过 `##` / `###` 显式声明。
121→5.  **禁止 HTML 实体**：Markdown 输入中禁止使用 `&gt;`、`&lt;`、`&amp;` 等 HTML 实体字符，必须使用原始符号 (`>`, `<`, `&`)。渲染端已内置自动解码，但输入端应保持纯净。
122→6.  **禁止紧凑加粗**：中文语境下，加粗文本 `**...**` 若与普通文本紧密相连（尤其是包含英文字符时），极易导致解析器边界识别错误。必须在加粗内容前后保留**一个空格**。
123→    - **错误**：`MPHm实现**堵塞度↓36%**与**QoS↑21%**的双重优化`
124→    - **正确**：`MPHm实现 **堵塞度↓36%** 与 **QoS↑21%** 的双重优化`

---

## 5. 最佳实践 (Best Practices)

为确保文档的可读性与美观性，建议遵循以下实践（源自 FORMAT_SPEC 经验）：

1.  **Section 综述**：
    由于禁止孤儿文本，若需对章节进行综述，请在章节下的第一个位置创建一个 `### 综述 {card-style="summary", col-span=3}` 的全宽卡片。
    
2.  **字数控制**：
    单个卡片（Card）的内容建议不超过 **200 字**。若内容过长，请考虑拆分为多个维度的卡片（如“原理”、“实现”、“优缺点”）。

3.  **拒绝“光杆司令”**：
    尽量避免一个 Section 下只有一个 Card。若内容较少，可考虑合并 Section；若内容较多，应拆分为多个 Card 以利用 Grid 布局优势。

4.  **形态搭配**：
    - **Wide Card** (`col-span=2`): 适合放置宽代码块、时序图、复杂表格。
    - **Tall Card** (`row-span=2`): 适合放置移动端截图、竖向流程图。

---

## 6. 协议价值

- **对 AI**：解析任务从“自然语言理解”降维为“正则匹配+浅层语义分类”，模型参数量需求降低 99% (7B -> 50MB)。
- **对渲染**：结构确定，布局可控，彻底消除 CSS 样式冲突和排版混乱。
- **对用户**：强制进行结构化思考，输出逻辑更清晰的文档。
